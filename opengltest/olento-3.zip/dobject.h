#ifndef opengltest_dobject_h
#define opengltest_dobject_h

#include <vector>
#include <iostream>
#include <time.h>

class dFace;
class dFacesConnected;
class dObject;

class dClock{
public:
	clock_t lastTime;
	
	void reset() {lastTime = clock();	}
	
	float get() {
		clock_t time = clock() - lastTime;
		return ((float)time / CLOCKS_PER_SEC);
	}

	dClock(){
		reset();
	}

};


//========================================= dFace =======================================//
//=======================================================================================//

class dFace
{
	std::vector<unsigned int> vertsIds;

public:
	glm::vec3 faceNormal;

	dFace(std::vector<unsigned int> _vertsIds) 
		: vertsIds(_vertsIds)
	{}
	
	void calculateFaceNormal(std::vector<glm::vec3>& allVerts)
	{
		glm::vec3 verts[3] = { allVerts[vertsIds[0]], allVerts[vertsIds[1]], allVerts[vertsIds[2]] };

		glm::vec3 vect1;
		glm::vec3 vect2;

		vect1 = verts[1] - verts[0];
		vect2 = verts[2] - verts[0];

		faceNormal = glm::cross(vect1, vect2);
	}
};

//===================================== dFacesConnected =================================//
//=======================================================================================//


class dFacesConnected {
    std::vector<unsigned int> faceIds;
    
public:
    
	void addFace(unsigned int Id) {
		faceIds.push_back(Id);
	}

    dFacesConnected(unsigned int vertexId,
                    std::vector<unsigned int> elements,
                    std::vector<dFace>& faces,
                    std::vector<glm::vec3> normals)
                    {   
        // get references from faces by elements and vertexId
        for(int i = 0; i < elements.size(); i++) {
            if (elements[i] == vertexId) {
                faceIds.push_back(i/3);
            }
        }
    }


	dFacesConnected() {}
    

	glm::vec3 calculateVertexNormal(std::vector<dFace>& allFaces) {
		glm::vec3 sum = glm::vec3(0, 0, 0);

		for (int i = 0; i < faceIds.size(); i++) 
			sum += allFaces[faceIds[i]].faceNormal;

		return glm::normalize(sum);
	}
};

//======================================== dObject =========================================//
//==========================================================================================//
//                                                                                          //
// dObject is object for openGl. The goal is to make class that is easy read and handle     //
// with main openGl's loop.                                                                 //
// dObject needs to be able to calculate normals on the go. That is made in the subclasses  //
// dFace and dFaceConnected. These two calsses are reference classes with one               //
// or two functions.                                                                        //
//                                                                                          //
//==========================================================================================//

class dObject {
public:
    dObject(std::string path);
    dObject(std::vector<glm::vec3> _vertices, std::vector<unsigned int> _elements);
    std::vector<glm::vec3> vertices;
    std::vector<glm::vec3> normals;
    std::vector<unsigned int> elements;
    
    
    void calculateAllNormals();
    bool loadOBJ(std::string path);
    
    std::vector<dFace> faces;
    std::vector<dFacesConnected> vFacesConnected;

private:
  
    void makeFaces();
    void makeFacesConnected();
    
};

dObject::dObject (std::string path)

{
    loadOBJ(path);
    
    
    makeFaces();
    makeFacesConnected();
    
    calculateAllNormals();
    
}


dObject::dObject (std::vector<glm::vec3> _vertices, std::vector<unsigned int> _elements):
                    vertices(_vertices),
                    normals(_vertices),
                    elements(_elements)

{
    makeFaces();
    makeFacesConnected();
    
    calculateAllNormals();
    
}

void dObject::makeFaces() //t�t� pit�isi optimoida!
{
	dClock c;
	std::cout << "makeFaces...";

	for (std::vector<unsigned int>::iterator it = elements.begin();
			it != elements.end();
			it += 3) {
        
		std::vector<unsigned int> ids(it, it+3);
		faces.push_back(dFace(ids));
    }
    
	std::cout << " ok ("<<c.get()<< " s)\n";
}

void dObject::makeFacesConnected()
{
	dClock c;

	std::cout << "makeFacesConnected... ";
	vFacesConnected.resize(vertices.size());

	for (int i = 0; i < elements.size(); i++) {
		vFacesConnected[elements[i]].addFace(i / 3);
	}
	std::cout << "ok (" << c.get() << " s)\n";
}


void dObject::calculateAllNormals()
{
	//std::cout << "calculateAllNormals: vFacesConnected.size = " << vFacesConnected.size() << "\n";
	dClock c;
    for(int i = 0; i < faces.size(); i++) {
        faces[i].calculateFaceNormal(vertices);
    }
    
	//std::cout << "face normals done (took "<< c.get() <<" s)\n";
	c.reset();
    for(int i = 0; i < vFacesConnected.size() && i < normals.size(); i++) {
        normals[i] = vFacesConnected[i].calculateVertexNormal(faces);
    }

	//std::cout << "vertex normals done (took " << c.get() << " s)\n";
}


/*
std::vector < glm::vec3 > loadVertices(const char* path) {
    // reading an entire binary file
    
    std::streampos bytes;
    long int vertices;
    std::vector< glm::vec3 > result;
    
    std::ifstream file(path, std::ios::in | std::ios::binary | std::ios::ate);
    if (file.is_open())
    {
        bytes = file.tellg();
        vertices = bytes / sizeof(glm::vec3);
        result.resize(vertices);
        
        file.seekg(0, std::ios::beg);
        file.read((char*)&result[0], bytes);
        file.close();
        
        std::cout << "Read " << vertices << " vertices\n";
    }
    else std::cout << "Unable to open file " << path << "\n";
    
    return result;
}

std::vector <unsigned int> loadElements(const char* path) {
    std::streampos bytes;
    long int elements;
    std::vector< unsigned int > result;
    
    std::ifstream file(path, std::ios::in | std::ios::binary | std::ios::ate);
    if (file.is_open())
    {
        bytes = file.tellg();
        elements = bytes / sizeof(unsigned int);
        result.resize(elements);
        
        file.seekg(0, std::ios::beg);
        file.read((char*)&result[0], bytes);
        file.close();
        
        std::cout << "Read " << elements << " elements\n";
    }
    else std::cout << "Unable to open file " << path << "\n";
    
    return result;
}

*/

// OBJLoader
// Very, VERY simple OBJ loader.
// Here is a short list of features a real function would provide :
// - Binary files. Reading a model should be just a few memcpy's away, not parsing a file at runtime. In short : OBJ is not very great.
// - Animations & bones (includes bones weights)
// - Multiple UVs
// - All attributes should be optional, not "forced"
// - More stable. Change a line in the OBJ file and it crashes.
// - More secure. Change another line and you can inject code.
// - Loading from memory, stream, etc

bool dObject::loadOBJ(
             std::string path){
    printf("Loading OBJ file %s...\n", path.c_str());
    
    std::vector<unsigned int> vertexIndices, normalIndices;
    std::vector<glm::vec3> temp_vertices;
    std::vector<glm::vec2> temp_uvs;
    std::vector<glm::vec3> temp_normals;
    
    
    FILE * file = fopen(path.c_str(), "r");
    if( file == NULL ){
        printf("Impossible to open the file ! Are you in the right path ? See Tutorial 1 for details\n");
        getchar();
        return false;
    }
    
    while( 1 ){
        
        char lineHeader[128];
        // read the first word of the line
        int res = fscanf(file, "%s", lineHeader);
        if (res == EOF)
            break; // EOF = End Of File. Quit the loop.
        
        // else : parse lineHeader
        
        if ( strcmp( lineHeader, "v" ) == 0 ){
            glm::vec3 vertex;
            fscanf(file, "%f %f %f\n", &vertex.x, &vertex.y, &vertex.z );
            temp_vertices.push_back(vertex);
        }else if ( strcmp( lineHeader, "vt" ) == 0 ){
            glm::vec2 uv;
            fscanf(file, "%f %f\n", &uv.x, &uv.y );
            uv.y = -uv.y; // Invert V coordinate since we will only use DDS texture, which are inverted. Remove if you want to use TGA or BMP loaders.
            temp_uvs.push_back(uv);
        }else if ( strcmp( lineHeader, "vn" ) == 0 ){
            glm::vec3 normal;
            fscanf(file, "%f %f %f\n", &normal.x, &normal.y, &normal.z );
            temp_normals.push_back(normal);
        }else if ( strcmp( lineHeader, "f" ) == 0 ){
            std::string vertex1, vertex2, vertex3;
            unsigned int vertexIndex[3], normalIndex[3];
            int matches = fscanf(file, "%d//%d %d//%d %d//%d\n", &vertexIndex[0],&normalIndex[0], &vertexIndex[1],&normalIndex[1], &vertexIndex[2],&normalIndex[2]);
            
            if (matches != 6){
                printf("File can't be read by our simple parser :-( Try exporting with other options\n");
                return false;
            }
            
            // use these to make Face
            vertexIndices.push_back(vertexIndex[0]);
            vertexIndices.push_back(vertexIndex[1]);
            vertexIndices.push_back(vertexIndex[2]);
            //uvIndices    .push_back(uvIndex[0]);
            //uvIndices    .push_back(uvIndex[1]);
            //uvIndices    .push_back(uvIndex[2]);
            normalIndices.push_back(normalIndex[0]);
            normalIndices.push_back(normalIndex[1]);
            normalIndices.push_back(normalIndex[2]);
            elements.push_back(vertexIndex[0] - 1);
            elements.push_back(vertexIndex[1] - 1);
            elements.push_back(vertexIndex[2] - 1);
            
        }else{
            // Probably a comment, eat up the rest of the line
            char stupidBuffer[1000];
            fgets(stupidBuffer, 1000, file);
        }
    }
    
    // For each vertex of each triangle
    for( unsigned int i=0; i<vertexIndices.size(); i++ ){
        
        // Get the indices of its attributes
        //   unsigned int vertexIndex = vertexIndices[i];
        // unsigned int uvIndex = uvIndices[i];
        unsigned int normalIndex = normalIndices[i];
        
        // Get the attributes thanks to the index
        //  glm::vec3 vertex = temp_vertices[ vertexIndex-1 ];
        //glm::vec2 uv = temp_uvs[ uvIndex-1 ];
        glm::vec3 normal = temp_normals[ normalIndex-1 ];
        
        // Put the attributes in buffers
        // out_vertices.push_back(vertex);
        //out_uvs     .push_back(uv);
        normals .push_back(normal);
        
    }
    vertices = temp_vertices;
    normals = temp_normals;
    
    return true;
}

#endif
