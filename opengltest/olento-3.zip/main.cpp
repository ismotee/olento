//main.cpp
#include "olento.h"

#include "shader.hpp"
#include "objloader.hpp"
#include "oWindow.h"
#include "dobject.h"
#include "oBuffers.h"
#include "oCamera.h"


// Include standard headers
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <time.h>
#include <iostream>

//using namespace glm;

// Random Float
float randf(float min, float max) {
	return ((float)rand() / RAND_MAX) * (max - min) + min;
}

void initialize() {
	srand(time(NULL));

	//initialize window and context
	oWindow::init();

	// Dark blue background
	glClearColor(0.0f, 0.0f, 0.4f, 0.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Accept fragment if it closer to the camera than the former one
	glDepthFunc(GL_LESS);

	// Cull triangles which normal is not towards the camera
	glEnable(GL_CULL_FACE);
}

int main(int argc, char* argv[]) {

	initialize();

	oBuffers::init();

	// Create and compile our GLSL program from the shaders
	std::string shaderDir = "/Users/ismotorvinen/Documents/3d/opengltest/opengltest/";
	std::string vertexShaderPath = shaderDir + "StandardShading.vertexshader";
	std::string fragmentShaderPath = shaderDir + "StandardShading.fragmentshader";
    std::string objectDir = shaderDir + "olento_testi.obj";

	GLuint programID = LoadShaders(vertexShaderPath.c_str(), fragmentShaderPath.c_str());
    dObject obj = dObject(objectDir);

    std::cout << "vertices: " << obj.vertices.size() << "\n";
    std::cout << "normals: " << obj.normals.size() << "\n";
    std::cout << "elements: " << obj.elements.size() << "\n";

    oBuffers::setElements(obj.elements);
    
    oCamera::init(programID);
    

	glUseProgram(programID);
	GLuint LightID = glGetUniformLocation(programID, "LightPosition_worldspace");

	//pääluuppi alkaa
	while (oWindow::getCloseEvent() == false){

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glUseProgram(programID);

		oBuffers::updateBuffers(obj);
        
        oCamera::update();
        
		//set light
		glm::vec3 lightPos = glm::vec3(4, 4, 4);
		glUniform3f(LightID, lightPos.x, lightPos.y, lightPos.z);

		//update vertices & normals
		oBuffers::updateAttributes();

		// Draw
		//glDrawElements(GL_TRIANGLES, obj.elements.size(), GL_UNSIGNED_INT, 0);

		GLenum err = glGetError();
		if (err != 0) std::cout << "Error: " << err << "\n";

		//show
		oWindow::show();

		//alter vertices & normals
		for (int i = 0; i < obj.vertices.size(); i++)
			obj.vertices[i] = obj.vertices[i] + glm::vec3(randf(-0.01f, 0.01f), randf(-0.01f, 0.01f), randf(-0.01f, 0.01f));
		obj.calculateAllNormals();

	}

	oBuffers::close();
	glDeleteProgram(programID);

	oWindow::close();
	return 0;
}